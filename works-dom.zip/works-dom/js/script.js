
var btnsAddTag = document.getElementsByClassName("add");
var btnsremoveTag = document.getElementsByClassName("remove");
var btnsdeleteTag = document.getElementsByClassName("delete");
var checkTags = document.querySelectorAll(".check");
var iconimgs = document.getElementsByClassName("fas fa-heartbeat");
console.log(iconimgs)

for (var i = 0; i < btnsAddTag.length; i++) {
  btnsAddTag[i].addEventListener("click", addition);
}
for (var k = 0; k < btnsremoveTag.length; k++) {
  btnsremoveTag[k].addEventListener("click", subtraction);
}
for (var k = 0; k < btnsdeleteTag.length; k++) {
  btnsdeleteTag[k].addEventListener("click", deleted);
}
for (var j = 0; j < checkTags.length; j++) {
  checkTags[j].onclick = totalPrice;
}
for (var j = 0; j < iconimgs.length; j++) {
  iconimgs[j].addEventListener("click", colore);
}
function addition(event) {
  var btnAdd = event.target;
  var tdElt = btnAdd.parentElement;
  var quantityTag = tdElt.querySelector(".quantity");
  var quantity = Number(quantityTag.value);
  quantity++;
  console.log(quantity);
  quantityTag.value = quantity;
  var trElt = btnAdd.parentElement.parentElement;
  var priceTag = trElt.querySelector(".price");
  var price = Number(priceTag.innerHTML);
  var unitPriceTag = trElt.querySelector(".unitPrice");
  var unitPrice = Number(unitPriceTag.innerHTML);
  price = unitPrice * quantity;
  priceTag.innerHTML = price;
}
function subtraction(event) {
  var btnremove = event.target;
  
  var tdElt = btnremove.parentElement;
  var quantityTag = tdElt.querySelector(".quantity");
  var quantity = Number(quantityTag.value);
  if(quantity>0){
  quantity--;
  console.log(quantity);

 }
  quantityTag.value = quantity;
  var trElt = btnremove.parentElement.parentElement;
  var priceTag = trElt.querySelector(".price");
  var price = Number(priceTag.innerHTML);
  var unitPriceTag = trElt.querySelector(".unitPrice");
  var unitPrice = Number(unitPriceTag.innerHTML);
  price = unitPrice * quantity;
  priceTag.innerHTML = price;
}
function deleted(event){
var btndelete=event.target;
var btnElt = btndelete.parentElement;

var trElt = btndelete.parentElement.parentElement;
var par=trElt.parentElement;
var priceTag = trElt.querySelector(".price");
var price = Number(priceTag.innerHTML);
var totalTag = document.getElementById("total");
var total = Number(totalTag.innerHTML);
var quantityTag = trElt.querySelector(".quantity");
var quantity = Number(quantityTag.value);
quantity=0;
quantityTag.value = quantity;

var check=trElt.querySelector(".check");

if(check.checked===true){
  total -= price;}
  par.removeChild(trElt);
  totalTag.innerHTML = total;

}

function totalPrice(event) {
  
  var check = event.target;
  var totalTag = document.getElementById("total");
  var total = Number(totalTag.innerHTML);
  var trElt = check.parentElement.parentElement;
  var imgtag = trElt.getElementsByClassName("fas fa-heartbeat");
  var btndelete= trElt.querySelector(".delete");
  var priceTag = trElt.querySelector(".price");
  var price = Number(priceTag.innerHTML);
  var btnAdd = trElt.querySelector(".add")
  var btnRemove = trElt.querySelector(".remove")
  console.log(imgtag)
  // imgtag.setAttribute(,true);
  if (check.checked) {
    total += price;
    btnAdd.setAttribute("disabled",true)
    btnRemove.setAttribute("disabled",true)
  
    
    
  }
  else{
      total-=price
      btnAdd.removeAttribute("disabled")
      btnRemove.removeAttribute("disabled")
     
  }
  totalTag.innerHTML = total;
}
function colore(event)
{
  var btncolor = event.target;
  // var icon = btncolor.parentElement;
  if(btncolor.style.color==="red"){
    btncolor.style.color="black";
  }else{
    btncolor.style.color="red"
  }
}